(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  const fallbackImage = (label, wide = false) => {
    const safe = encodeURIComponent(label);
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`<?xml version="1.0"?><svg xmlns="http://www.w3.org/2000/svg" width="${wide ? 1200 : 800}" height="${wide ? 700 : 1000}" viewBox="0 0 800 1000"><rect width="800" height="1000" fill="#100c0d"/><rect x="26" y="26" width="748" height="948" fill="none" stroke="#c9a866" stroke-opacity=".35"/><circle cx="400" cy="420" r="130" fill="#4b141d" fill-opacity=".42"/><text x="400" y="620" text-anchor="middle" fill="#eee7da" font-family="Georgia,serif" font-size="38">${safe}</text><text x="400" y="670" text-anchor="middle" fill="#a69d91" font-family="Arial,sans-serif" font-size="18" letter-spacing="4">PLACEHOLDER</text></svg>`)}`;
  };

  function setImage(img, src, label) {
    img.src = src;
    img.onerror = () => {
      img.onerror = null;
      img.src = fallbackImage(label);
    };
  }

  // Intro
  const intro = $("#intro");
  const site = $("#site");
  const introName = $("#intro-name");
  const yesButton = $("#yes-button");
  const noButton = $("#no-button");
  const noReaction = $("#no-reaction");

  introName.textContent = CONTENT.introName;
  intro.style.backgroundImage = `url("${CONTENT.introBackground}")`;

  noButton.addEventListener("click", () => {
    noReaction.textContent = "zorre me cague haciendo esta mamada de regalo, lo vas a mirar igual 😡";
    noReaction.classList.remove("visible");
    requestAnimationFrame(() => noReaction.classList.add("visible"));
  });

  yesButton.addEventListener("click", enterSite);

  function enterSite() {
    intro.style.opacity = "0";
    intro.style.visibility = "hidden";
    intro.setAttribute("aria-hidden", "true");
    site.classList.add("visible");
    site.setAttribute("aria-hidden", "false");
    setTimeout(() => intro.remove(), 850);
  }

  // Profile
  $("#profile-title").textContent = CONTENT.profile.title;
  $("#profile-alias").textContent = CONTENT.profile.alias;
  setImage($("#profile-image"), CONTENT.profile.image, "Alex");
  $("#profile-text").textContent = CONTENT.profile.text;
  $("#final-title").textContent = CONTENT.final.title;
  $("#final-text").textContent = CONTENT.final.text;
  $("#conclusion").textContent = CONTENT.test.conclusion;
  $("#punchline").textContent = CONTENT.test.punchline;

  // Navigation
  const sections = $$(".content-section");
  $$(".nav-link").forEach(btn => {
    btn.addEventListener("click", () => showSection(btn.dataset.section));
  });

  function showSection(id) {
    sections.forEach(section => section.classList.toggle("active-section", section.id === id));
    $$(".nav-link").forEach(btn => btn.classList.toggle("active", btn.dataset.section === id));
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (id === "final") startConfetti();
  }

  // Mains
  const mainsGrid = $("#mains-grid");
  CONTENT.mains.forEach((main, index) => {
    const card = document.createElement("article");
    card.className = "main-card";
    card.innerHTML = `
      <img alt="${escapeHtml(main.name)}" />
      <div class="main-card-info">
        <span>${String(index + 1).padStart(2, "0")} · FILE</span>
        <h3>${escapeHtml(main.name)}</h3>
      </div>`;
    setImage($("img", card), main.image, main.name);
    card.addEventListener("click", () => openMainModal(main));
    mainsGrid.appendChild(card);
  });

  const modal = $("#main-modal");
  $("#modal-title").textContent = "";
  $$("[data-close-modal]").forEach(el => el.addEventListener("click", closeMainModal));
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeMainModal(); });

  function openMainModal(main) {
    setImage($("#modal-image"), main.image, main.name);
    $("#modal-image").alt = main.name;
    $("#modal-title").textContent = main.name;
    $("#modal-text").textContent = main.text;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  }
  function closeMainModal() {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
  }

  // Music
  const audio = $("#audio-player");
  const playButton = $("#play-track");
  const progress = $("#progress");
  const volume = $("#volume");
  const titleEl = $("#track-title");
  const artistEl = $("#track-artist");
  const currentTimeEl = $("#current-time");
  const durationEl = $("#duration");
  const playlist = $("#playlist");
  let currentTrack = -1;

  $("#track-count").textContent = `${CONTENT.music.length} ${CONTENT.music.length === 1 ? "canción" : "canciones"}`;
  audio.volume = Number(volume.value);

  CONTENT.music.forEach((track, index) => {
    const item = document.createElement("div");
    item.className = "track-item";
    item.innerHTML = `
      <div class="track-num">${String(index + 1).padStart(2, "0")}</div>
      <div><div class="track-name">${escapeHtml(track.title)}</div><div class="track-artist">${escapeHtml(track.artist)}</div></div>
      <div class="track-status">SELECT</div>`;
    item.addEventListener("click", () => loadTrack(index, true));
    playlist.appendChild(item);
  });

  function loadTrack(index, autoplay = false) {
    if (!CONTENT.music[index]) return;
    currentTrack = index;
    const track = CONTENT.music[index];
    audio.src = track.file;
    titleEl.textContent = track.title;
    artistEl.textContent = track.artist;
    progress.value = "0";
    currentTimeEl.textContent = "0:00";
    durationEl.textContent = "0:00";
    $$(".track-item", playlist).forEach((item, i) => {
      item.classList.toggle("active", i === index);
      $(".track-status", item).textContent = i === index ? "CURRENT" : "SELECT";
    });
    if (autoplay) audio.play().catch(() => {});
  }
  playButton.addEventListener("click", () => {
    if (currentTrack === -1 && CONTENT.music.length) loadTrack(0, false);
    if (audio.paused) audio.play().catch(() => {}); else audio.pause();
  });
  $("#prev-track").addEventListener("click", () => {
    if (!CONTENT.music.length) return;
    loadTrack((currentTrack - 1 + CONTENT.music.length) % CONTENT.music.length, true);
  });
  $("#next-track").addEventListener("click", () => {
    if (!CONTENT.music.length) return;
    loadTrack((currentTrack + 1) % CONTENT.music.length, true);
  });
  audio.addEventListener("play", () => playButton.textContent = "Ⅱ");
  audio.addEventListener("pause", () => playButton.textContent = "▶");
  audio.addEventListener("loadedmetadata", () => durationEl.textContent = formatTime(audio.duration));
  audio.addEventListener("timeupdate", () => {
    if (!Number.isNaN(audio.duration) && audio.duration > 0) progress.value = String((audio.currentTime / audio.duration) * 100);
    currentTimeEl.textContent = formatTime(audio.currentTime);
  });
  audio.addEventListener("ended", () => {
    if (CONTENT.music.length) loadTrack((currentTrack + 1) % CONTENT.music.length, true);
  });
  progress.addEventListener("input", () => {
    if (!audio.duration) return;
    audio.currentTime = (Number(progress.value) / 100) * audio.duration;
  });
  volume.addEventListener("input", () => audio.volume = Number(volume.value));

  function formatTime(seconds) {
    if (!Number.isFinite(seconds)) return "0:00";
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  }

  // Test
  const testStart = $("#test-start");
  const testQuestion = $("#test-question");
  const testAnalyzing = $("#test-analyzing");
  const testResults = $("#test-results");
  const questionText = $("#question-text");
  const questionIndex = $("#question-index");
  const answerButtons = $("#answer-buttons");
  const reaction = $("#reaction");
  let testIndex = 0;
  const answers = [];
  let analysisTimer = null;
  let autoFinalTimer = null;

  $("#start-test").addEventListener("click", startTest);

  function startTest() {
    answers.length = 0;
    testIndex = 0;
    showTestState(testQuestion);
    renderQuestion();
  }

  function renderQuestion() {
    const q = CONTENT.test.questions[testIndex];
    if (!q) return finishTest();
    questionIndex.textContent = `${String(testIndex + 1).padStart(2, "0")} / ${String(CONTENT.test.questions.length).padStart(2, "0")}`;
    questionText.textContent = q.text;
    reaction.textContent = "";
    answerButtons.innerHTML = "";
    q.answers.forEach((answer, idx) => {
      const button = document.createElement("button");
      button.textContent = answer;
      button.addEventListener("click", () => chooseAnswer(answer, q.reactions?.[idx] ?? "Anotado."));
      answerButtons.appendChild(button);
    });
  }

  function chooseAnswer(answer, response) {
    answers.push({ question: CONTENT.test.questions[testIndex].text, answer });
    $$("#answer-buttons button").forEach(btn => btn.disabled = true);
    reaction.textContent = response;
    setTimeout(() => {
      testIndex += 1;
      if (testIndex >= CONTENT.test.questions.length) finishTest();
      else renderQuestion();
    }, 1000);
  }

  function finishTest() {
    showTestState(testAnalyzing);
    clearTimeout(analysisTimer);
    analysisTimer = setTimeout(showResults, Number(CONTENT.test.resultDelay) || 3800);
  }

  function showResults() {
    renderResults();
    showTestState(testResults);
    clearTimeout(autoFinalTimer);
    autoFinalTimer = setTimeout(() => {
      showSection("final");
      testResults.classList.remove("active-state");
      testStart.classList.add("active-state");
    }, Number(CONTENT.test.autoAdvanceDelay) || 5200);
  }

  function renderResults() {
    const list = $("#results-list");
    list.innerHTML = "";
    CONTENT.test.results.forEach(([name, value]) => {
      const number = Math.max(0, Math.min(100, parseInt(value, 10) || 0));
      const row = document.createElement("div");
      row.className = "result-row";
      row.innerHTML = `<div class="result-name">${escapeHtml(name)}</div><div class="result-bar"><div class="result-fill" style="width:${number}%"></div></div><div class="result-value">${escapeHtml(value)}</div>`;
      list.appendChild(row);
    });
  }

  function showTestState(state) {
    [testStart, testQuestion, testAnalyzing, testResults].forEach(s => s.classList.remove("active-state"));
    state.classList.add("active-state");
  }

  // Final confetti: canvas-only, no dependency.
  let confettiStarted = false;
  function startConfetti() {
    if (confettiStarted) return;
    confettiStarted = true;
    const canvas = $("#confetti-canvas");
    const ctx = canvas.getContext("2d");
    let particles = [];
    let running = true;
    let last = performance.now();
    const palette = ["#4b141d", "#721f2b", "#c9a866", "#eee7da", "#171011"];

    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = canvas.clientWidth * dpr;
      canvas.height = canvas.clientHeight * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    window.addEventListener("resize", resize);
    resize();

    const amount = Math.min(120, Math.max(55, Math.floor(window.innerWidth / 11)));
    for (let i = 0; i < amount; i++) {
      particles.push({
        x: Math.random() * canvas.clientWidth,
        y: Math.random() * -canvas.clientHeight,
        size: 4 + Math.random() * 7,
        speed: 35 + Math.random() * 70,
        drift: (Math.random() - .5) * 24,
        rotate: Math.random() * Math.PI,
        rotateSpeed: (Math.random() - .5) * 2,
        color: palette[Math.floor(Math.random() * palette.length)],
        life: 3 + Math.random() * 4
      });
    }

    function loop(now) {
      if (!running) return;
      const dt = Math.min(.03, (now - last) / 1000);
      last = now;
      ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
      particles.forEach(p => {
        p.y += p.speed * dt;
        p.x += Math.sin(now / 800 + p.y / 200) * p.drift * dt;
        p.rotate += p.rotateSpeed * dt;
        p.life -= dt * .02;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotate);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
        ctx.restore();
        if (p.y > canvas.clientHeight + 20) {
          p.y = -20;
          p.x = Math.random() * canvas.clientWidth;
        }
      });
      requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);
    setTimeout(() => { running = false; ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight); }, 7500);
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;" }[char]));
  }
})();
