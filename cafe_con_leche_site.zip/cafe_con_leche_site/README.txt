CAFÉ CON LECHE · GUÍA RÁPIDA
==============================

Este proyecto funciona como una página web estática. No necesita servidor, base de datos, API keys ni frameworks.

ESTRUCTURA
----------
index.html       -> estructura de la página. Normalmente NO hace falta tocarlo.
style.css        -> diseño visual. Déjalo intacto si solo quieres cambiar contenido.
script.js        -> funcionamiento. Déjalo intacto.
content.js       -> TODO el contenido editable.
assets/images/   -> coloca aquí tus imágenes.
assets/audio/    -> coloca aquí tus canciones.

1. IMAGEN DE FONDO INICIAL
---------------------------
Coloca tu imagen en:
assets/images/intro-bg.jpg

Luego abre content.js y busca:
introBackground: "assets/images/intro-bg.jpg"

Puedes cambiar el nombre del archivo si lo necesitas.

2. IMAGEN DE PERFIL
--------------------
Coloca tu imagen en:
assets/images/profile.jpg

En content.js está indicado así:
image: "assets/images/profile.jpg"

3. TEXTO DEL PERFIL
--------------------
En content.js busca:
profile: {
  title: "Café con Leche",
  alias: "Cafecito · Alexa · Alex",
  image: "assets/images/profile.jpg",
  text: `Aquí escribiré...`
}

Reemplaza SOLO el texto que está entre las comillas invertidas. Puedes escribir varios párrafos.

4. LOS 15 MAINS
---------------
Cada personaje tiene esta forma:
{
  name: "Lan Zhan",
  image: "assets/images/main01.jpg",
  text: `Aquí escribiré...`
}

Para cambiar uno, modifica name, image y text.
No hace falta tocar script.js.

Hay 15 placeholders preparados: main01.jpg hasta main15.jpg.

Puedes AGREGAR más personajes copiando otro bloque dentro de mains: [ ... ].
Puedes QUITAR personajes borrando su bloque completo.

5. MÚSICA
---------
Coloca los archivos de audio en:
assets/audio/

Ejemplo:
assets/audio/song01.mp3

En content.js:
music: [
  {
    title: "Nombre de canción",
    artist: "Artista",
    file: "assets/audio/song01.mp3"
  }
]

Puedes agregar o quitar canciones copiando o borrando bloques.

La música se reproduce directamente en la página con el reproductor incorporado. El navegador puede impedir la reproducción automática hasta que el usuario pulse un control. Eso es una regla habitual de los navegadores, no un fallo del proyecto.

6. PREGUNTAS DEL TEST
---------------------
Cada pregunta usa:
{
  text: "¿Qué preferís?",
  answers: ["Opción A", "Opción B"],
  reactions: ["Reacción A", "Reacción B"]
}

La reacción 0 corresponde a la respuesta 0, la reacción 1 a la respuesta 1, etc.

Para agregar más respuestas, agrega más elementos en answers y la misma cantidad en reactions.

Puedes agregar MUCHAS más preguntas copiando un bloque dentro de test.questions.

7. RESULTADOS
-------------
En content.js encontrarás:
results: [
  ["MIGAJERO", "97%"],
  ["HETERO", "24%"],
  ["GAY", "66%"],
  ["LESBIANA", "10%"],
  ["OMEGA", "100%"]
]

Puedes cambiar nombres y porcentajes libremente.
Los resultados están diseñados como un informe humorístico y no representan un cálculo real.

8. FRASES FINALES DEL TEST
---------------------------
Estas dos frases están separadas para que puedas editarlas fácilmente:

test.conclusion
test.punchline

Los textos actuales conservan exactamente el chiste indicado en el pedido original.

9. CARTA FINAL
--------------
Busca:
final: {
  title: "Para vos, Café con Leche",
  text: `Aquí escribiré mi carta final...`
}

Reemplaza title y text. El texto admite saltos de línea y varios párrafos.

10. CAMBIAR LOS ALIAS
----------------------
Puedes cambiar:
introName
profile.title
profile.alias

No necesitas buscar esos datos en otros archivos.

11. PLACEHOLDERS
----------------
Si todavía no pusiste una imagen, la página mostrará una tarjeta placeholder en lugar de romperse.
Los archivos de audio inexistentes simplemente no podrán reproducirse hasta que coloques tus MP3.

12. PUBLICAR GRATIS
-------------------
GITHUB PAGES
1. Crea un repositorio nuevo en GitHub.
2. Sube TODO el contenido de esta carpeta manteniendo la estructura de carpetas.
3. En Settings -> Pages, selecciona la rama principal y la carpeta raíz.
4. GitHub generará un enlace público.

NETLIFY
1. Crea una cuenta gratuita.
2. Arrastra la carpeta del proyecto al área de despliegue, o conecta un repositorio GitHub.
3. Netlify publicará el sitio y te dará un enlace.

CLOUDFLARE PAGES
1. Crea un proyecto nuevo.
2. Conecta el repositorio o sube el proyecto según la opción disponible.
3. Usa la carpeta raíz del proyecto como contenido estático.

13. MUY IMPORTANTE SOBRE LOS ARCHIVOS
--------------------------------------
Conserva estas rutas:
assets/images/
assets/audio/

Si cambias un nombre de archivo, cambia también su ruta en content.js.

14. PROBAR LOCALMENTE
---------------------
Puedes abrir index.html directamente en el navegador para probar la mayoría de las funciones.
La música local y algunas restricciones del navegador pueden comportarse de forma distinta al abrir archivos con file://.
Para una prueba idéntica a la publicación real, subir el proyecto a GitHub Pages, Netlify o Cloudflare Pages es lo más fiable.

15. NAVEGACIÓN Y FUNCIONES
---------------------------
Perfil     -> retrato + descripción personal.
Mains      -> cuadrícula de personajes + ventana de detalle.
Música     -> reproductor y playlist local.
Test       -> preguntas una por una + análisis automático + resultados.
Final      -> carta + confeti automático.

No hay backend ni datos externos necesarios para ejecutar la página.
