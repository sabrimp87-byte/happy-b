// ============================================================
// CONTENIDO EDITABLE
// ============================================================
// Cambia únicamente este archivo para personalizar el regalo.
// No necesitas tocar script.js.

const CONTENT = {
  introName: "Café con Leche",
  introBackground: "assets/images/intro-bg.jpg",

  profile: {
    title: "Café con Leche",
    alias: "Cafecito · Alexa · Alex",
    image: "assets/images/profile.jpg",
    text: `Aquí escribiré mi descripción personal para Alex.

Podés usar varios párrafos y saltos de línea. Reemplazá este texto por tu propio mensaje.`
  },

  mains: [
    { name: "Lan Zhan", image: "assets/images/main01.jpg", text: "Aquí escribiré por qué me recuerda a Alex..." },
    { name: "Hua Cheng", image: "assets/images/main02.jpg", text: "Aquí escribiré por qué me recuerda a Alex..." },
    { name: "Personaje 03", image: "assets/images/main03.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 04", image: "assets/images/main04.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 05", image: "assets/images/main05.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 06", image: "assets/images/main06.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 07", image: "assets/images/main07.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 08", image: "assets/images/main08.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 09", image: "assets/images/main09.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 10", image: "assets/images/main10.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 11", image: "assets/images/main11.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 12", image: "assets/images/main12.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 13", image: "assets/images/main13.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 14", image: "assets/images/main14.jpg", text: "Aquí escribiré..." },
    { name: "Personaje 15", image: "assets/images/main15.jpg", text: "Aquí escribiré..." }
  ],

  music: [
    { title: "Canción 01", artist: "Artista", file: "assets/audio/song01.mp3" },
    { title: "Canción 02", artist: "Artista", file: "assets/audio/song02.mp3" },
    { title: "Canción 03", artist: "Artista", file: "assets/audio/song03.mp3" }
  ],

  test: {
    questions: [
      {
        text: "¿Qué preferís, frío o calor?",
        answers: ["Frío", "Calor"],
        reactions: ["Interesante...", "Mmm... anotado."]
      },
      {
        text: "¿Helado o pastel?",
        answers: ["Helado", "Pastel"],
        reactions: ["Decisión importante.", "Esto dice cosas sobre vos."]
      },
      {
        text: "¿Lan Zhan o Hua Cheng?",
        answers: ["Lan Zhan", "Hua Cheng"],
        reactions: ["Elección respetable.", "Registro la evidencia."]
      },
      {
        text: "¿Día o noche?",
        answers: ["Día", "Noche"],
        reactions: ["Tomado en cuenta.", "Eso explica bastante."]
      }
    ],

    results: [
      ["MIGAJERO", "97%"],
      ["HETERO", "24%"],
      ["GAY", "66%"],
      ["LESBIANA", "10%"],
      ["OMEGA", "100%"]
    ],

    resultDelay: 3800,
    conclusion: "me toco el mejor amigo mas nuc y rarete de todos pero, pos ya que 💜",
    punchline: "JAJAJAJAJAJA mentira cafe con leche, yo te asno my love",
    autoAdvanceDelay: 5200
  },

  final: {
    title: "Para vos, Café con Leche",
    text: `Aquí escribiré mi carta final...

Podés escribir varios párrafos, dejar espacios y crear un mensaje largo.`
  }
};
